import{_ as e,o as c,c as a}from"./index-79509884.js";const n={};function o(t,r){return c(),a("div",null," This is an about page ")}const _=e(n,[["render",o]]);export{_ as default};
