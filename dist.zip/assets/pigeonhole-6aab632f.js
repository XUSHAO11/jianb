import{_ as e,o as c,c as o}from"./index-79509884.js";const n={};function r(s,t){return c(),o("div",null," services ")}const a=e(n,[["render",r]]);export{a as default};
