import{_ as e,o as c,c as r}from"./index-79509884.js";const n={};function o(s,t){return c(),r("div",null," search ")}const _=e(n,[["render",o]]);export{_ as default};
